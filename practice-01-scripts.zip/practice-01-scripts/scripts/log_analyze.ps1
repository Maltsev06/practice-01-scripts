param(
    [Parameter(Mandatory=$true)] [string]$LogFile,
    [Parameter(Mandatory=$true)] [ValidateSet("INFO","WARNING","ERROR")] [string]$Level
)

# Resolve path
try { $absLog = (Resolve-Path $LogFile).Path } 
catch { Write-Error "Log file not found: $LogFile"; exit 1 }

$base = (Get-Location).Path
if (-not $absLog.StartsWith($base)) { Write-Error "Log file must be inside practice-01-scripts"; exit 1 }

$lines = Get-Content $absLog | Where-Object { $_ -match $Level }
Write-Output ("Lines with {0}: {1}" -f $Level, $lines.Count)
Write-Output "First 3 lines:"
$lines | Select-Object -First 3
Write-Output "Last 3 lines:"
$lines | Select-Object -Last 3

# Unique dates
$dates = $lines | ForEach-Object { if ($_ -match "^\d{4}-\d{2}-\d{2}") { $matches[0] } }
Write-Output "Unique dates count: $($dates | Sort-Object -Unique | Measure-Object).Count"