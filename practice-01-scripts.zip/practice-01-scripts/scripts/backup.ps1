param(
    [Parameter(Mandatory=$true)] [string]$Source,
    [Parameter(Mandatory=$true)] [string]$Destination
)

# Resolve absolute paths
try { $absSource = (Resolve-Path $Source).Path } 
catch { Write-Error "Source folder not found: $Source"; exit 1 }

try { 
    $absDestination = (Resolve-Path $Destination -ErrorAction SilentlyContinue)
    if (-not $absDestination) { 
        New-Item -ItemType Directory -Path $Destination -Force | Out-Null
        $absDestination = (Resolve-Path $Destination).Path
    } else { $absDestination = $absDestination.Path }
} catch { Write-Error "Cannot create destination folder: $Destination"; exit 1 }

# Safety check
$base = (Get-Location).Path
if (-not ($absSource.StartsWith($base) -and $absDestination.StartsWith($base))) {
    Write-Error "Paths must be inside practice-01-scripts"
    exit 1
}

# Create backup folder
$timestamp = Get-Date -Format "yyyy-MM-dd_HHmmss"
$backupFolder = Join-Path $absDestination $timestamp
New-Item -ItemType Directory -Path $backupFolder | Out-Null

# Copy files
try {
    $files = Copy-Item -Path "$absSource\*" -Destination $backupFolder -Recurse -PassThru
    Write-Output "Backup created: $backupFolder"
    Write-Output "Files copied: $($files.Count)"
} catch { Write-Error "Copy failed: $_"; exit 1 }