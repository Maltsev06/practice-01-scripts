param(
    [Parameter(Mandatory=$true)] [string]$Target,
    [switch]$DryRun
)

# Resolve path
try { $absTarget = (Resolve-Path $Target).Path } 
catch { Write-Error "Folder not found: $Target"; exit 1 }

# Safety checks
if ($absTarget -eq "/" -or $absTarget -match "^[a-zA-Z]:\\$") { Write-Error "Unsafe path"; exit 1 }
$base = (Get-Location).Path
if (-not ($absTarget.StartsWith($base))) { Write-Error "Path must be inside practice-01-scripts"; exit 1 }

# Find temp files
$files = Get-ChildItem -Path $absTarget -Include *.tmp,*.bak,*.cache -File -Recurse
if ($DryRun) {
    Write-Output "Files to be deleted:"
    $files.FullName
} else {
    $files | Remove-Item -Force
    Write-Output "Deleted files: $($files.Count)"
}