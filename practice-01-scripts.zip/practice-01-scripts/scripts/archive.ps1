param(
    [Parameter(Mandatory=$true)] [string]$Source,
    [Parameter(Mandatory=$true)] [string]$ArchiveDir
)

# Resolve paths
try { $absSource = (Resolve-Path $Source).Path } 
catch { Write-Error "Source folder not found: $Source"; exit 1 }

try { 
    $absArchiveDir = (Resolve-Path $ArchiveDir -ErrorAction SilentlyContinue)
    if (-not $absArchiveDir) { New-Item -ItemType Directory -Path $ArchiveDir -Force | Out-Null; $absArchiveDir = (Resolve-Path $ArchiveDir).Path }
    else { $absArchiveDir = $absArchiveDir.Path }
} catch { Write-Error "Cannot create archive folder: $ArchiveDir"; exit 1 }

# Safety
$base = (Get-Location).Path
if (-not ($absSource.StartsWith($base) -and $absArchiveDir.StartsWith($base))) {
    Write-Error "Paths must be inside practice-01-scripts"
    exit 1
}

# Archive
$sourceName = Split-Path $absSource -Leaf
$timestamp = Get-Date -Format "yyyy-MM-dd_HHmmss"
$archiveName = "${sourceName}__arch_$timestamp.zip"
$archivePath = Join-Path $absArchiveDir $archiveName

try {
    Compress-Archive -Path "$absSource\*" -DestinationPath $archivePath -Force
    $size = (Get-Item $archivePath).Length
    Write-Output "Archive created: $archivePath"
    Write-Output "Archive size: $size bytes"
} catch { Write-Error "Archiving failed: $_"; exit 1 }